package edu.s1.enactusprototypev00;

/**
 * Created by S1 on 30/01/2018.
 */

public class Config {

    private Config(){

    }

    public static final String YOUTUBE_API_KEY = "AIzaSyBK0LpRf8RWKD1cIgerNRRJmFmedJOPidQ";

}
