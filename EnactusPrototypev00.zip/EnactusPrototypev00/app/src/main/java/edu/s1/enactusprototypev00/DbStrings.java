package edu.s1.enactusprototypev00;

/**
 * Created by S1 on 30/01/2018.
 */

public class DbStrings {

    static final String DATABASE_URL = "192.168.1.248:3306";
    static final String DATABASE_NAME = "mydb";
    static final String USERNAME = "u1";
    static final String PASSWORD = "123e";

}
